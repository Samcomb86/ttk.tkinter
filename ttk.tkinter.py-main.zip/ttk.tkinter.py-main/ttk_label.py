import tkinter as tk
from tkinter import ttk
root = tk.Tk()
ttk.Label(root, text="Hello, Ttk!").pack()
root.mainloop()
