import tkinter as tk
from tkinter import ttk
root = tk.Tk()
ttk.Menubutton(root, text="Options").pack()
root.mainloop()
