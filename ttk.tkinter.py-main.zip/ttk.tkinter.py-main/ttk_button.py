import tkinter as tk
from tkinter import ttk
root = tk.Tk() #creating window
ttk.Button(root, text="Click Me").pack() #making a theme button
root.mainloop()
