# ttk.tkinter.py
ttk.tkinter is used to make your window more beautiful and attractive.
Differnet between tk and ttk in tkinter in python.
Tkinter:
  1)Description: Tkinter is the standard Python interface to the Tk GUI toolkit. It provides a variety of widgets (such as buttons, labels, and text boxes) for           building GUI applications.
  2)Look and Feel: Tkinter widgets have a basic and traditional appearance.
  3)Theming: Tkinter’s theming capabilities are limited.
  4)Cross-Platform Appearance: Tkinter provides a consistent but basic appearance across platforms.
  5)Widget Set: Tkinter includes a standard set of widgets suitable for basic applications.
  6)Customization: Widgets can be customized directly using widget-specific options.
  7)Performance: Adequate for simple applications.
  8)Complexity: Easier to use for beginners.
Tkinter.ttk:
  1)Description: The ttk module, available in Python’s standard library, provides themed widgets.
  2)Look and Feel: ttk widgets offer a modern and polished look, integrating better with native applications on various operating systems.
  3)Theming: Enhanced theming options using pre-defined styles and themes.
  4)Cross-Platform Appearance: Adapts to the native look and feel of the operating system.
  5)Widget Set: Extends the standard set with visually appealing and functional widgets.
  6)Customization: Uses a style-based customization approach through the ttk.Style class.
  7)Performance: Better for complex and visually demanding applications.
  8)Complexity: Introduces more complexity but offers greater flexibility and visual appeal.
