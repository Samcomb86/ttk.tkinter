import tkinter as tk
from tkinter import ttk
root = tk.Tk()
ttk.Scrollbar(root, orient="vertical").pack()
root.mainloop()
