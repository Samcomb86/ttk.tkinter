import tkinter as tk
from tkinter import ttk
root = tk.Tk()
ttk.Frame(root).pack()
root.mainloop()
