import tkinter as tk
from tkinter import ttk
root = tk.Tk()
ttk.Radiobutton(root, text="Option 1").pack()
root.mainloop()
